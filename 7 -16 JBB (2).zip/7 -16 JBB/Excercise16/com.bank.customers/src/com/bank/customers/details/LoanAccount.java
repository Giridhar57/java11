package com.bank.customers.details;

public class LoanAccount {
	
	String accountId;
	String accountType;
	String LcustomerId;
	int ROI;
	String loanType;
	double principal;
	int months;
	
	static int aid = 100;

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId() {
		this.accountId = "A"+ ++aid;
	}

	public String getLcustomerId() {
		return LcustomerId;
	}

	public void setLcustomerId(String id) {
		LcustomerId = id;
	}

	public int getROI() {
		return ROI;
	}

	public void setROI(int rOI) {
		ROI = rOI;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public double getPrincipal() {
		return principal;
	}

	public void setPrincipal(double principal) {
		this.principal = principal;
	}

	public int getMonths() {
		return months;
	}

	public void setMonths(int months) {
		this.months = months;
	}

	public static int getAid() {
		return aid;
	}

	public static void setAid(int aid) {
		LoanAccount.aid = aid;
	}

	public String getAccountType() {
		return accountType;
	}
	
	public void setAccountType() {
		this.accountType = "LA";
	}
	
	public LoanAccount() {
		super();
	}
	
	
}
