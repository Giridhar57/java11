package com.infy.assignment.annotation;

public class Customer {
	public void calculateAmount(int amount){
		System.out.println("the total amount");
	}
}

