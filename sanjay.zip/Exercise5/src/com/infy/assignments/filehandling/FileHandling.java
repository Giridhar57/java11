package com.infy.assignments.filehandling;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

public class FileHandling {

	public static void main(String[] args) throws IOException {
		try {

			BufferedReader reader1 = new BufferedReader(new FileReader(
					""));
			BufferedReader reader2 = new BufferedReader(new FileReader(
					""));

			BufferedWriter writer = new BufferedWriter(new FileWriter(
					""));

			String l1, l2;

			l1 = reader1.readLine();
			l2 = reader2.readLine();
			System.out.println(l1);
			writer.write(l1 + " " + l2);

			reader1.close();
			reader2.close();
			writer.close();

		}

		catch (IOException e) {
			e.printStackTrace();
		}

	}

}