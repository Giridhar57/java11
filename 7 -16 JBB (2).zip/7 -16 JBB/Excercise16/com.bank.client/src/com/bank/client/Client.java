package com.bank.client;
import java.util.*;
import com.bank.customers.service.*;
public class Client {
	
	public static void main(String[] args) {
		
		CustomerService customerServiceImpl = new CustomerServiceImpl();
		
		int choice = 0;
		Scanner scanner = new Scanner(System.in);
		
		try {
			do {
				System.out.println();
				System.out.println("************************************");
				System.out.println("::Welcome to BANK Application::");
				System.out.println("************************************");
				System.out.println("1. Create Account");
				System.out.println("2. Create Savings Account");
				System.out.println("3. Create Loan Account");
				System.out.println("4. View Account Details");
				System.out.println("5. View Saving Details");
				System.out.println("6. View Loan Details");
				System.out.println("7. Exit");
				System.out.println("Enter your choice::");
				choice = scanner.nextInt();
				
				switch (choice) {
				case 1:
					customerServiceImpl.createAccount();
					break;
				case 2:
					customerServiceImpl.createSavingsAccount();
					break;
					
				case 3:
					customerServiceImpl.createLoanAccount();
					break;
				
				case 4:
					customerServiceImpl.ViewAccountDetails();;
					break;

				case 5:
					customerServiceImpl.ViewSavingsAccountDetails();
					break;
					
				case 6:
					customerServiceImpl.ViewLoanAccountDetails();
					break;
					
				case 7:
					System.out.println("Exiting the application");
					System.exit(0);
					return;
				default:
					System.out.println("Invalid input!!! Please re-enter choice from our menu");
				}
			} while (choice != 7);
			scanner.close();
		} catch (Exception e) {
			scanner.close();
			e.printStackTrace();
		}
	}
	
}
