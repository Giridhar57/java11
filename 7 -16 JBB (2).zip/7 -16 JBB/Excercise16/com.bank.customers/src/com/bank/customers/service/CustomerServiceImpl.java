package com.bank.customers.service;
import java.util.*;

import com.bank.customers.data.AddData;
import com.bank.customers.details.Customer;
import com.bank.customers.details.LoanAccount;
import com.bank.customers.details.SavingsAccount;

public class CustomerServiceImpl implements CustomerService {

	Scanner sc = new Scanner(System.in);
	AddData addData = new AddData();
	
	@Override
	public void createAccount() {
		System.out.println("Enter The Details to Create Account: ");
		
		System.out.println("Enter the Name: ");
		String name = sc.next();
		
		System.out.println("Enter the D.O.B: ");
		System.out.println("dd-mm-yyyy");
		String dob = sc.next();
		
		System.out.println("Enter the Address: ");
		String address = sc.next();

		System.out.println("Enter the Phone Number: ");
		String mobile = sc.next();
		
		System.out.println("Enter the Password: ");
		String password = sc.next();
		
		addData.addData(name, dob, address, mobile, password);
		System.out.println("Normal Account is Created");
	
	}
	
	@Override
	public void createSavingsAccount() {
		
		System.out.println("Enter the details to create the Savings Account:");
		
		System.out.println("Enter your Account ID:");
		int id = sc.nextInt();
		
		System.out.println("Enter the deposit amount:");
		int balance = sc.nextInt();
		
		addData.addSavingsAccountData(balance, id);
	}
	
	
	@Override
	public void createLoanAccount() {
		
		System.out.println("Enter the details to create the Loan Account:");
		
		System.out.println("Enter your Account ID:");
		int id = sc.nextInt();
		
		System.out.println("Enter your ROI:");
		int roi = sc.nextInt();
		
		System.	out.println("Enter your Loan type:");
		String loanType = sc.next();
		
		System.out.println("Enter your Principal amount:");
		double principal = sc.nextDouble();
		
		System.out.println("Enter your Duration:");
		int duration = sc.nextInt();
		
		addData.addLoanAccountData(roi, loanType, principal, duration, id);
	}

	@Override
	public void ViewAccountDetails() {
		
		System.out.println("Enter the Customer Id: ");
		int id = sc.nextInt();
		
		if(validateAccountDetails(id))
		{
			Customer customer = addData.getBankDetail(id);
			System.out.println("********************ACCOUNT DETAILS********************");
			System.out.println("Customer Id: "+id);
			System.out.println("Customer Name: "+customer.getCustomerName());
			System.out.println("Customer D.O.B: "+customer.getDob());
			System.out.println("Customer Address: "+customer.getAddress());
			System.out.println("Customer Mobile: "+customer.getMobile());
			System.out.println("Customer password: "+customer.getPassword());
			System.out.println("******************************************************");
			System.out.println();
			
		}else
		{
			System.out.println("Enter the valid Customer Id");
		}
		
	}

	@Override
	public void ViewSavingsAccountDetails() {
		
		System.out.println("Enter the Customer Id: ");
		int id = sc.nextInt();
		1
		if(validateSavingAccount(id))
		{
			SavingsAccount savingAccount = addData.getSavingAccountDetails(id);
			
			System.out.println("***************SAVINGS ACCOUNT DETAILS********************");
			System.out.println("Account Id: "+"A"+id);
			System.out.println("Account Type: "+savingAccount.getAccountType());
			System.out.println("Customer ID: "+savingAccount.getSCustomerId());
			System.out.println("Minimum Balence: "+savingAccount.getMinBalance());
			System.out.println("Available Balence: "+savingAccount.getBalance());
			System.out.println("******************************************************");
			System.out.println();
			
		}else
		{
			System.err.println("This ID is not associated with any accounts, First create the account to continue");
		}
		
	}

	@Override
	public void ViewLoanAccountDetails() {
		
		System.out.println("Enter the Customer Id: ");
		int id = sc.nextInt();
		
		if(validateLoanAccount(id))
		{
			LoanAccount LoanAccount = addData.getLoanAccountDetails(id);
			
			System.out.println("**************LOAN ACCOUNT DETAILS********************");
			System.out.println("Account Id: "+"L"+id);
			System.out.println("Account Type: "+LoanAccount.getAccountType());
			System.out.println("Customer ID: "+LoanAccount.getLcustomerId());
			System.out.println("ROI: "+LoanAccount.getROI());
			System.out.println("LoanType: "+LoanAccount.getLoanType());
			System.out.println("principal: "+LoanAccount.getPrincipal());
			System.out.println("Duration: "+LoanAccount.getMonths());
			System.out.println("******************************************************");
			System.out.println();
			
		}else
		{
			System.err.println("This ID is not associated with savings accounts, First create the saving account to continue");
		}
	}
	
	@Override
	public boolean validateAccountDetails(int id) {

		if(addData.customerDetails.containsKey(id))
		{
			return true;
		}
		
		return false;
	}
	
	@Override
	public boolean validateSavingAccount(int id) {
		
		if(addData.savingsAccountDetails.containsKey("S"+id))
		{
			return true;
		}
		
		return false;
	}

	@Override
	public boolean validateLoanAccount(int id) {
		if(addData.loanAccountDetails.containsKey("L"+id))
		{
			return true;
		}
		
		return false;
	}
}
