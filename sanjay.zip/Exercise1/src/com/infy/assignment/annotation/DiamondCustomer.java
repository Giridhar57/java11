package com.infy.assignment.annotation;

public class DiamondCustomer extends Customer{
	@Override
	public void calculateAmount(int amount) {
		System.out.println("diamond customer");
	}
	
}
