package com.infy.assignments.serialization;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class Result{
	public static void main(String args[]) throws IOException {
	try {
			
		
	//Creation of Files
	BufferedReader reader1=new BufferedReader (
	new FileReader("C:\\Users\\devanshi.singh\\eclipse-workspace2\\Exercise3\\JohnTerm1.txt"));
	
	BufferedReader reader2=new BufferedReader (
	new FileReader("C:\\Users\\devanshi.singh\\eclipse-workspace2\\Exercise3\\JohnTerm2.txt"));
	
	BufferedWriter writer=new BufferedWriter(
    new FileWriter("C:\\Users\\devanshi.singh\\eclipse-workspace2\\Exercise3\\JohnTotal.txt"));
        	
        	
	
	List<String> line1=new ArrayList<>();
	List<String> line2=new ArrayList<>();
	
    String l1,l2;
	while((l1=reader1.readLine())!=null) {
		line1.add(l1);
	}
	while((l2=reader2.readLine())!=null) {
		line2.add(l2);
	}
	for(int i=0;i<line1.size();i++) {
		String [] marks1=line1.get(i).split(" ");
		String [] marks2=line2.get(i).split(" ");
		
		int totalMarksEnglish=Integer.parseInt(marks1[0])+Integer.parseInt(marks2[0]);
		int totalMarksMaths=Integer.parseInt(marks1[1])+Integer.parseInt(marks2[1]);
		int totalMarkScience=Integer.parseInt(marks1[2])+Integer.parseInt(marks2[2]);
		
		writer.write(totalMarksEnglish+ " "+totalMarksMaths+ " "+totalMarkScience);
		writer.newLine();
	}
	reader1.close();
	reader2.close();
	writer.close();
	}
	catch(IOException e)
	{
		e.printStackTrace();
	}
	}

}

