package com.infosys.traversing_lists;

import java.util.Arrays;
import java.util.List;

public class CountryCaseChange {
	  public static void main(String[] args) {
	     List<String> listCountries = Arrays.asList("France", "Germany", "Italy", "Egypt");
	     listCountries.sort((String stringArg1, String stringArg2) ->   stringArg1.compareTo(stringArg2)); 
//	     for (String countryName : listCountries) {
//		      System.out.println(countryName);
//	     }
	     listCountries.stream().forEach(System.out::println);
	  }
}

//Modify the given class to use internal iteration to print all the country names in ascending order.


//import java.util.*;
// 
//public class CountryCaseChange {
//  public static void main(String[] args) {
//     List<String> listCountries = Arrays.asList("France", "Germany", "Italy", "Egypt");
//     countrylst.sort((String stringArg1, String stringArg2) ->   stringArg1.compareTo(stringArg2)); 
//     for (String countryName : listCountries) {
//	      System.out.println(countryName);
//     }
//  }
//}
