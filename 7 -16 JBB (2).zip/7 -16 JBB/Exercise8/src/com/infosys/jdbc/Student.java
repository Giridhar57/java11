package com.infosys.jdbc;

import java.sql.*;
public class Student {
	public static void main(String args[]) throws ClassNotFoundException,SQLException {
		Class.forName("org.postgresql.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/jbb","postgres","postgres");
		
		Statement s = con.createStatement();
		String sql = "create table Student(Name varchar(24),RollNumber int, CourseName varchar(24), Score int);";
		s.execute(sql);
		System.out.println("Table created");
		Statement stmt = con.createStatement();
		String insertion1 = "insert into student values ('Jagadeesh',101,'JDBC',95);";
		String insertion2 = "insert into student values ('Chandu',102,'JDBC',90);";
		String insertion3 = "insert into student values ('Sandeep',103,'JDBC',58);";
		String insertion4 = "insert into student values ('Murthy',104,'Java',59);";
		String insertion5 = "insert into student values ('John',105,'Java',60);";
		
		stmt.execute(insertion1);
		stmt.execute(insertion2);
		stmt.execute(insertion3);
		stmt.execute(insertion4);
		stmt.execute(insertion5);
		
		String retrieval = "select * from student where coursename = 'JDBC' and score>=60;";
		ResultSet rs =stmt.executeQuery(retrieval);
		
		while(rs.next()) {
			System.out.println(rs.getString("Name")+" "+rs.getString("CourseName")+" "+rs.getInt("Score"));
		}
	}
	
}
//Students are enrolled in different online courses and have taken the online assessment for these courses. Their assessment marks have to be stored in the database by a Java program. The data stored for each student is
//
//Name, Roll Number, CourseName, Score (percentage)
//
//Student table can be created using the below DDL statement 
//
//create table Student(Name varchar(24),RollNumber int, CourseName varchar(24), Score int)
//
//Using JDBC API perform the following operations
//
//Insert 5 student's records in the table.
//
//Retrieve and display the details of the students who have scored more than 60% in the course ‘JDBC’ on the console.
//
