package com.infy.assignments.buffer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.Buffer;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("all")
public class TotalMarks {

	public static void main(String[] args) {
		try {
			
		BufferedReader b1 = new BufferedReader
	    (new FileReader("C:\\Users\\devanshi.singh\\eclipse-workspace2\\Exercise4\\JohnTerm1.txt"));
		BufferedReader b2 = new BufferedReader
		(new FileReader("C:\\Users\\devanshi.singh\\eclipse-workspace2\\Exercise4\\JohnTerm2.txt"));
		BufferedWriter write = new BufferedWriter
		(new FileWriter("C:\\Users\\devanshi.singh\\eclipse-workspace2\\Exercise4\\JohnTotal.txt"));
		
		String line1,line2;
		  while ((line1 = b1.readLine()) != null && (line2 = b2.readLine()) != null) {
              String[] marksTerm1 = line1.split(" ");
              String[] marksTerm2 = line2.split(" ");
              
              int totalMarksEnglish = Integer.parseInt(marksTerm1[0]) + Integer.parseInt(marksTerm2[0]);
              int totalMarksMaths = Integer.parseInt(marksTerm1[1]) + Integer.parseInt(marksTerm2[1]);
              int totalMarksScience = Integer.parseInt(marksTerm1[2]) + Integer.parseInt(marksTerm2[2]);

              // Writing the total marks for each subject to the JohnTotal.txt file
              write.write(totalMarksEnglish + " " + totalMarksMaths + " " + totalMarksScience);
              write.newLine();
		}
		  b1.close();
		  b2.close();
		  write.close();
		}
		
		catch(IOException e)
		{
			e.printStackTrace();
		}
	
	}
	

}
