package com.infosys.lambda;

public class Main {
	public static void main(String args[]) {
	StringFormatter spaceFormatter = (s1,s2)-> s1+" "+s2;
	StringFormatter hiphenFormatter = (s1,s2)->s1+"-"+s2;
	StringFormatter capitalizeFormatter = (s1,s2)-> s1.toUpperCase()+" "+s2.toUpperCase();
	
	System.out.println(spaceFormatter.format("Lambda","Expression"));
	System.out.println(hiphenFormatter.format("Lambda","Expression"));
	System.out.println(capitalizeFormatter.format("Lambda","Expression"));
	
	
	
	}
	
	
}

//Define a functional interface called StringFormatter that should contain the abstract method,
//
//String format(String string1, String string2);
//
//Create a main class that contains lambda expressions to implement the StringFormatter interface by defining the format() method in the following three different ways for the inputs: s1 = “Lambda”, s2 = “Expression”
//
//Returns "Lambda Expression"
//
//Returns "Lambda – Expression"
//
//Returns "LAMBDA EXPRESSION"
