package com.infosys.functional_interfaces;

import java.util.function.BiFunction;

public class CalculatorQuiz {
	public static void main (String args[]) {
        // call evaluate for adding two int values
        // call evaluate for subtracting two int values
        // call evaluate for multiplying two int values
		Integer i =10;
		Integer j =12;
		System.out.println(evaluate(i,j,(t,u)->t+u));
		System.out.println(evaluate(i,j,(t,u)->t-u));
		System.out.println(evaluate(i,j,(t,u)->t*u));
		
		
    }
 
    public static Integer evaluate(Integer t, Integer u, BiFunction<Integer, Integer, Integer> fn) {
        return fn.apply(t, u);
    }
}

//Write a Calculator class using lambda expressions to add, subtract and multiply two int values.
//
//import java.util.function.BiFunction;
//import java.util.function.BiFunction;
 
//public class CalculatorQuiz {
//    //main
//    public static void main (String pars[]) {
//        // call evaluate for adding two int values
//        // call evaluate for subtracting two int values
//        // call evaluate for multiplying two int values
//    }
// 
//    public static Integer evaluate(Integer t, Integer u, BiFunction<Integer, Integer, Integer> fn) {
//        return fn.apply(t, u);
//    }
//}
//
