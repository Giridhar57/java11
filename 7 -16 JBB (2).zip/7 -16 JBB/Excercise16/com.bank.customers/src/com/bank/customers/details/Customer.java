package com.bank.customers.details;

public class Customer {

	private int CustomerId;
	private String customerName;
	private String dob;
	private String address;
	private String mobile;
	private String password;
	
	static int id= 1000;
	
	public int getCustomerId() {
		return CustomerId;
	}
	public void setCustomerId() {
		CustomerId = ++id;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public Customer() {
		super();
	}
	
	public Customer(String customerName, String dob, String address, String mobile, String password) {
		super();
		this.CustomerId = CustomerId;
		this.customerName = customerName;
		this.dob = dob;
		this.address = address;
		this.mobile = mobile;
		this.password = password;
	}
	
	@Override
	public String toString() {
		return "Customer{" + "CustomerId=" + CustomerId + ", CustomerName='" + customerName + '\'' + ", D.O.B=" + dob + ", Address="
				+ address + ", Mobile=" + mobile + ", password='" + password + '\'' + '}';
	}
}
