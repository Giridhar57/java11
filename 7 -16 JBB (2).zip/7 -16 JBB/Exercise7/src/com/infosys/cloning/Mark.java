package com.infosys.cloning;

import java.util.Map;

public class Mark implements Cloneable{
	private String subject;
	private double marks;
	private Term term;
	private Map<String, String> props;
	
	
    public Mark(String subject, double marks, Term term, Map<String, String> props) {
		super();
		this.subject = subject;
		this.marks = marks;
		this.term = term;
		this.props = props;
	}
    
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public double getMarks() {
		return marks;
	}
	public void setMarks(double marks) {
		this.marks = marks;
	}
	
	public Term getTerm() {
		return term;
	}
	public void setTerm(Term term) {
		this.term = term;
	}
	public Map<String, String> getProps() {
		return props;
	}
	public void setProps(Map<String, String> p) {
		this.props = p;
	}
	
	protected Object shallowClone() throws CloneNotSupportedException {
		return super.clone();
	}

	protected Object deepClone() throws CloneNotSupportedException {
		Mark m = (Mark)super.clone();
		m.setTerm((Term)m.getTerm().clone());
		return m;
	}
	
//	@Override
//	protected Object clone() throws CloneNotSupportedException {
//		Mark m = (Mark)super.clone();
//		m.setTerm((Term)m.getTerm().clone());
//		return m;
//	}
	@Override
	public String toString() {
		return "Mark [subject=" + subject + ", marks=" + marks + ", term=" + term + ", props=" + props + "]";
	}

	
	
	
	
}