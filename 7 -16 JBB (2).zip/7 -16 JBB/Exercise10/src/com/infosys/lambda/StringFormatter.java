package com.infosys.lambda;
@FunctionalInterface
public interface StringFormatter {
	String format(String s1,String s2);
}
