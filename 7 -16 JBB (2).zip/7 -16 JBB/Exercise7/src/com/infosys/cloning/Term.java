package com.infosys.cloning;

public class Term implements Cloneable{
	private String termName;
	private String studentId;
	
	
	public Term(String termName, String studentId) {
		super();
		this.termName = termName;
		this.studentId = studentId;
	}
	
	public String getTermName() {
		return termName;
	}
	public void setTermName(String termName) {
		this.termName = termName;
	}
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	@Override
	public String toString() {
		return "Term [termName=" + termName + ", studentId=" + studentId + "]";
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
	
	
	
	
	
}

//
//
//Problem Statement:
//
//Objective: To understand Cloning.
//
//Exercise Description
//
//Create a Mark class having attribute subject as String, marks as double, Term as the reference, and props as the map which holds the details of the student like department, city, and batch as shown.
//
//package com.infy.assignment.io;
//public class Mark  {
//	private String subject;
//	private double marks;
//	private Term term;
//	private Map<String, String> props;
//	
//    public String getSubject() {
//		return subject;
//	}
//	public void setSubject(String subject) {
//		this.subject = subject;
//	}
//	public double getMarks() {
//		return marks;
//	}
//	public void setMarks(double marks) {
//		this.marks = marks;
//	}
//	
//	public Term getTerm() {
//		return term;
//	}
//	public void setTerm(Term term) {
//		this.term = term;
//	}
//	public Map<String, String> getProps() {
//		return props;
//	}
//	public void setProps(Map<String, String> p) {
//		this.props = p;
//	}
//}
//
//Create another Term class that has termName as String and studentId as String.
//
// 
//
//package com.infy.assignment.io;
//public class Term  {
//	private String termName;
//	private String studentId;
//	
//	public String getTermName() {
//		return termName;
//	}
//	public void setTermName(String termName) {
//		this.termName = termName;
//	}
//	public String getStudentId() {
//		return studentId;
//	}
//	public void setStudentId(String studentId) {
//		this.studentId = studentId;
//	}
//}
//Note : Create constructors accordingly in the class.
//
//Write a Java program that creates original and cloned objects for classes. 
//Use the object clone method for the cloned reference.
//Do the required changes to Term and Mark classes by implementing the cloneable interface to achieve default/shallow cloning and deep cloning.
//package com.infy.assignment.io;
//public class Mark  {
//	private String subject;
//	private double marks;
//	private Term term;
//	private Map<String, String> props;
//	
//    public String getSubject() {
//		return subject;
//	}
//	public void setSubject(String subject) {
//		this.subject = subject;
//	}
//	public double getMarks() {
//		return marks;
//	}
//	public void setMarks(double marks) {
//		this.marks = marks;
//	}
//	
//	public Term getTerm() {
//		return term;
//	}
//	public void setTerm(Term term) {
//		this.term = term;
//	}
//	public Map<String, String> getProps() {
//		return props;
//	}
//	public void setProps(Map<String, String> p) {
//		this.props = p;
//	}
//}
//Create another Term class that has termName as String and studentId as String.
//
//package com.infy.assignment.io;
//public class Term  {
//	private String termName;
//	private String studentId;
//	
//	public String getTermName() {
//		return termName;
//	}
//	public void setTermName(String termName) {
//		this.termName = termName;
//	}
//	public String getStudentId() {
//		return studentId;
//	}
//	public void setStudentId(String studentId) {
//		this.studentId = studentId;
//	}
//}
//Note : Create constructors accordingly in the class.
//
//Write a Java program that creates original and cloned objects for classes. 
//Use the object clone method for the cloned reference.
//Do the required changes to Term and Mark classes by implementing the cloneable interface to achieve default/shallow cloning and deep cloning.
//
//
