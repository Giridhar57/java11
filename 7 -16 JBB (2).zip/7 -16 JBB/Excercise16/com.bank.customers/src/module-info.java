module com.bank.customers {
	exports com.bank.customers.service;
}