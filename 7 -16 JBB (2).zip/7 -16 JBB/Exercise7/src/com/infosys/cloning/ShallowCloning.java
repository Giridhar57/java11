package com.infosys.cloning;

import java.util.HashMap;
import java.util.Map;

public class ShallowCloning {
	public static void main(String args[]) {
		Term t1= new Term("First_Term","1001");
		Map<String,String> hm = new HashMap<>();
		hm.put("Department","CSE");
		hm.put("City", "Bangalore");
		hm.put("Batch","2023");
		Mark m1 = new Mark("English",95,t1,hm);
		Mark m2;
		try {
			m2 = (Mark)m1.shallowClone();
			m2.setMarks(96.0);
			m2.getTerm().setStudentId("101");
			System.out.println(m2);
			System.out.println(m1);
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		
		
	}
}
