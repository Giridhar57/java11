package com.infy.assignment.annotation;

import java.lang.annotation.*;

@Target(ElementType.METHOD)

public @interface RepeatedClass {
	MethodInfo[] value();
}
