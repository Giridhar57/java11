package com.bank.customers.details;

public class SavingsAccount{
	
	String accountId;
	String accountType;
	String ScustomerId;
	int minBalance;
	int balance;
	
	static int aid = 100;
	
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId() {
		this.accountId = "A"+ (++aid);
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType() {
		this.accountType = "SA";
	}
	public int getMinBalance() {
		return minBalance;
	}
	public void setMinBalance() {
		this.minBalance = 500;
	}
	public void setSCustomerId(int id) {
		this.ScustomerId = "S"+id;
	}
	public String getSCustomerId() {
		return ScustomerId;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	public SavingsAccount(String accountId,int balance) {
		super();
		this.accountId = accountId;
		this.ScustomerId = getSCustomerId();
		this.balance = balance;
	}
	public SavingsAccount() {
		super();
	}
	
	
}
