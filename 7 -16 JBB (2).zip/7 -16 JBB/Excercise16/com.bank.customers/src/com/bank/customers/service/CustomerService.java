package com.bank.customers.service;

public interface CustomerService {
	
	public void createAccount();
	public void createSavingsAccount();
	public void createLoanAccount();
	
	public void ViewAccountDetails();
	public void ViewSavingsAccountDetails();
	public void ViewLoanAccountDetails();
	
	public boolean validateAccountDetails(int id);
	public boolean validateSavingAccount(int id);
	public boolean validateLoanAccount(int id);
}
