package com.infy.assignment.annotation;
import java.lang.annotation.*;

@Repeatable(RepeatedClass.class)
@Retention(RetentionPolicy.CLASS)

public @interface MethodInfo {
	String author();
}
