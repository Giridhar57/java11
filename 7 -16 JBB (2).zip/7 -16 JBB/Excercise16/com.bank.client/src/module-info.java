module com.bank.client {
	requires com.bank.customers;
}