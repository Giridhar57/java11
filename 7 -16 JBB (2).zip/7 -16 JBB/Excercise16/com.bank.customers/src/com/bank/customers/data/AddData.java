package com.bank.customers.data;

import java.util.*;
import com.bank.customers.details.*;

public class AddData {
	
	public Map<Integer,Customer> customerDetails = new HashMap<>();
	public Map<String,SavingsAccount> savingsAccountDetails = new HashMap<String, SavingsAccount>();
	public Map<String,LoanAccount> loanAccountDetails = new HashMap<String, LoanAccount>();
	
	public void addData(String name,String dob,String address,String mobile,String password)
	{
		Customer customer = new Customer();
		customer.setCustomerId();
		customer.setCustomerName(name);
		customer.setDob(dob);
		customer.setAddress(address);
		customer.getMobile();
		customer.setPassword(password);
		
		customerDetails.put(customer.getCustomerId(), customer);
		System.out.println("Your Account is Created with Account Id of "+ customer.getCustomerId());
	}
	
	public void addSavingsAccountData(int balance,int id)
	{
		if(customerDetails.containsKey(id))
		{
			SavingsAccount savingsAccount = new SavingsAccount();
			savingsAccount.setAccountId();
			savingsAccount.setAccountType();
			savingsAccount.setSCustomerId(id);
			savingsAccount.setMinBalance();
			savingsAccount.setBalance(balance);
			
			savingsAccountDetails.put(savingsAccount.getSCustomerId(), savingsAccount);
			System.out.println("Your Account is Created with Account Id of "+ savingsAccount.getSCustomerId());
		}else
		{
			System.err.println("Enter the valid Account ID");
		}
	}
	
	public void addLoanAccountData(int ROI,String loantype, double principal, int duration,int id)
	{
		
		if(customerDetails.containsKey(id))
		{
			LoanAccount loanAccount =  new LoanAccount();
			loanAccount.setAccountId();
			loanAccount.setAccountType();
			loanAccount.setLcustomerId("L"+id);
			loanAccount.setROI(ROI);
			loanAccount.setLoanType(loantype);
			loanAccount.setPrincipal(principal);
			loanAccount.setPrincipal(principal);
			
			loanAccountDetails.put( loanAccount.getLcustomerId(), loanAccount);
			System.out.println("Your Account is Created with Account Id of "+ loanAccount.getLcustomerId());
		}else
		{
			System.err.println("Enter the valid Account ID");
		}
		
	}
	
	public Customer getBankDetail(int id)
	{
		return customerDetails.get(id);
	}
	
	public SavingsAccount getSavingAccountDetails(int id)
	{
		return savingsAccountDetails.get("S"+id);
	}
	
	public LoanAccount getLoanAccountDetails(int id)
	{
		return loanAccountDetails.get("L"+id);
	}
}
