package com.infosys.stream;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {

	public static void main(String[] args) {
		Integer[] arr = {1,2,3,4,5};
		List<Integer> l =Arrays.asList(arr);
		List<Integer> resultList = l.stream().map(i-> i*i*i).collect(Collectors.toList());
		System.out.println(resultList);
		
		
		Stream<Integer> s =Stream.iterate(0, i->i<50, i->i+1);
		int sum = s.reduce(0,(i1,i2)->i1+i2);
		System.out.println("Sum of first 50 whole numbers : "+sum);
			
	}
}
//Given a list of numbers, return a list of the cube of each number. For example, given [1, 2, 3, 4, 5] you should return [1, 8, 27, 64, 125].
//
//Calculate the sum of the first 50 whole numbers using iterate() and reduce() methods of Stream