/**
 * 
 */
/**
 * 
 */
module Exercise8 {
	requires java.sql;
}