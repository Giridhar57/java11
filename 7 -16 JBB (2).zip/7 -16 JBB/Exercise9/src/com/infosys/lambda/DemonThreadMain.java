package com.infosys.lambda;

public class DemonThreadMain {
    public static void main(String pars[]) {
        Thread threadInstance = new Thread(new Runnable() {
            public void run() {
                System.out.println("Its me from thread");
            }
        });
        
        Thread instance = new Thread(() -> System.out.println("Its me from thread using Lambda"));
        
        threadInstance.start();
        instance.start();
        
    }
}

//Change the following anonymous Runnable class implementation to Lambda Expression:
//
//public class DemoThreadMain {
//    public static void main(String pars[]) {
//        Thread threadInstance = new Thread(new Runnable() {
//            //run --- implementation
//            public void run() {
//                System.out.println(" Its me from thread");
//            }
//        });
//        threadInstance.start();
//    }
//}

 