package com.infy.assignments.serialization;

public class Mark  {
	private String subject;
	private double marks;
	
        public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public double getMarks() {
		return marks;
	}
	public void setMarks(double marks) {
		this.marks = marks;
	}
}
