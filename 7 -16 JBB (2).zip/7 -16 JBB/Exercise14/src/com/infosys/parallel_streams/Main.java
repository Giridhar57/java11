package com.infosys.parallel_streams;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {

	public static void main(String[] args) {
		
		List<Integer> numbers = new ArrayList<>();
		for(int i=0;i<=1000;i++) {
			numbers.add(i);
		}
		long previous = System.currentTimeMillis();
		Long count = numbers.stream().filter(i-> i%2==1).collect(Collectors.counting());
		long now = System.currentTimeMillis();
		System.out.println("Normal stream execution time "+(now-previous)+" milli seconds");
		System.out.println("Count of numbers : "+count);
		
		previous=System.currentTimeMillis();
		Long parallelCount = numbers.stream().parallel().filter(i->i%2==1).collect(Collectors.counting());
		now = System.currentTimeMillis();
		System.out.println("Parallel stream execution time "+(now-previous)+" milli seconds");
		System.out.println("Count of numbers : "+parallelCount);
	}

}

//Create a List of integer numbers varying from 1 -1000. First, convert it to a Stream, then filter the even numbers and print the count of elements in the Stream.
//
//Capture the time taken to do the above operation. (Note: Use System.currentTimeMillis() method to capture the system time before and after the given operation and subtract the time values to get the time taken to complete the task.)
//
//Now perform the same operations on a Parallel Stream and capture the time taken by the Parallel Stream to complete the given task.
//
//Compare and understand the efficiency of the Parallel Stream.
