import java.util.*;
public class OptionalClass {
	
	public static void main(String[] args) {
		
		HashMap<String ,String> employeeDetails = new HashMap<String,String>();
		
		employeeDetails.put("Jagadeesh", "EMP01");
		employeeDetails.put("Murari", "EMP02");
		employeeDetails.put("Mahendar", null);
		employeeDetails.put("Karthick", null);
		employeeDetails.put("Nithinraaj", null);
		
		for(String s: employeeDetails.keySet())
		{
			String eid = employeeDetails.get(s);
			Optional<String> op = Optional.ofNullable(eid);
			String answer = op.map(id -> id+" bestSol").orElse("No Project Code Found");
			System.out.println(s +" : "+answer);
		}
		
		
	}
}
